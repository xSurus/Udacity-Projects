//only start making the grid when the form is submitted with values
document.addEventListener("submit", function makeGrid(event) {
    /**
    * @description creates a grid with the height and width given by the user
    * @param {number} height of the grid
    * @param {number} width of the grid
    */
    //event.preventDefaul() to stop it from reloading the page after submitting
    event.preventDefault();
    //getting the height and width from the submitted form
    //also setting the pixelCanvas to a variable called table
    var height = document.getElementById("inputHeight").value;
    var width = document.getElementById("inputWidth").value;
    var table = document.getElementById("pixelCanvas");
    //If the form is submitted again it'll clear the grid
    table.innerHTML = "";
    //for loop to loop over the height and create x columns, x being
    //the height at the end
    for (var x = 0; x < height; x++) {
      var tr = document.createElement("tr");
      //append the row to the grid/table
      table.appendChild(tr);
      //for every row create y columns
      for (var y = 0; y < width; y++) {
        var td = document.createElement("td");
        //for every td create an event that, if clicked, it changes the color
        /**
         * @description colors the clicked td into the color given by the user
         * @param {number} color
         */
        td.addEventListener("click", function colorChanger() {
          var color = document.getElementById("colorPicker").value;
          //changes its color to the color given by the input
          this.style.backgroundColor = color;
        });
        //appends every td as a child Element of the corresponding row
        tr.appendChild(td);
      };
    };
  });  