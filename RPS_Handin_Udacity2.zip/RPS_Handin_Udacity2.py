#!/usr/bin/env python3
import random
moves = ['rock', 'paper', 'scissors']


class Player:
    my_move = None
    their_move = None

    def move(self):
        return 'rock'

    def learn(self, my_move, their_move):
        self.my_move = my_move
        self.their_move = their_move


class Human(Player):
    def move(self):
        my_move = input("What is your Play?").lower()
        while my_move not in moves:
            my_move = input("Your move has to be either"
                            " rock, paper or scissors.")
        return my_move


class RandomPlayer(Player):
    def move(self):
        return random.choice(moves)


class ReflectPlayer(Player):
    def move(self):
        if not self.their_move:
            return random.choice(moves)
        else:
            return self.their_move


class Cycler(Player):
    def move(self):
        if self.my_move is None:
            return random.choice(moves)
        index = moves.index(self.my_move) + 1
        if index == len(moves):
            index = 0
        return moves[index]


class Game:
    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2
        # global p1s, p2s
        self.p1s = 0
        self.p2s = 0

    def beats(self, one, two):
        return ((one == 'rock' and two == 'scissors') or
                (one == 'scissors' and two == 'paper') or
                (one == 'paper' and two == 'rock'))

    def play_round(self):
        move1 = self.p1.move()
        move2 = self.p2.move()
        print(f"Player 1: {move1}  Player 2: {move2}")
        self.p1.learn(move1, move2)
        self.p2.learn(move2, move1)
        if self.beats(move1, move2) is True:
                self.p1s += 1
                print("Player one won this round")
        elif self.beats(move2, move1) is True:
                self.p2s += 1
                print("\nPlayer two won this round")
        elif move1 == move2:
                print("\nA draw! Seems challenging!")
        print(self.p1s, self.p2s)

    def play_game(self):
        print("Game start!")
        """This idea to check the input was taken from
        https://stackoverflow.com/questions/23326099/how-can-i-limit-the-user-
        input-to-only-integers-in-python"""
        while True:
            try:
                rounds = int(input("How many rounds do you want to play?"))
                break
            except:
                print("Your input has to be a number!")
        while type(rounds) != int:
            rounds = input("It has to be a number.")
        int(rounds)
        for round in range(rounds):
            print(f"Round {round}:")
            self.play_round()
        print(f"\nThe score is {self.p1s} to {self.p2s}")
        if self.p1s > self.p2s:
            print("\n Player 1 won the game, congratulations!!")
        elif self.p1s < self.p2s:
            print("\n Player 2 won the game, congratulations!!")
        else:
            print("\n It's a draw...")

if __name__ == '__main__':
    game = Game(Human(), ReflectPlayer())
game.play_game()
